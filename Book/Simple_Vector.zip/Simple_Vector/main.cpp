/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on December 8, 2015, 12:00 PM
 */

//
#include <iostream>
using namespace std;

//User Libraries
#include "SimpleVector.h"


int main(int argc, char** argv) {

    return 0;
}

